param([string]$JavaHome = 'C:\Program Files\Java\jdk-21',
      [string]$SdkJar = 'C:\work\KUKA\SW\KUKA.AMR_Fleet_2.15.1\STANDARD-API-2.15.5-jar-with-dependencies.jar')
$ErrorActionPreference = 'Stop'
$output = Join-Path $PSScriptRoot 'build'
$classes = Join-Path $output 'classes'
$testClasses = Join-Path $output 'tests'
New-Item -ItemType Directory -Force -Path $classes,$testClasses | Out-Null
$sources = @(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'src') -Recurse -Filter '*.java' | ForEach-Object FullName)
& "$JavaHome\bin\javac.exe" --release 8 -encoding UTF-8 -proc:none -cp $SdkJar -d $classes @sources
if ($LASTEXITCODE -ne 0) { throw 'Compile failed' }
$jarPath = Join-Path $output 'servostar-mes-transfer-0.1.0.jar'
& "$JavaHome\bin\jar.exe" cfm $jarPath (Join-Path $PSScriptRoot 'MANIFEST.MF') -C $classes .
if ($LASTEXITCODE -ne 0) { throw 'Packaging failed' }
$tests = @(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'test') -Filter '*.java' | ForEach-Object FullName)
& "$JavaHome\bin\javac.exe" -encoding UTF-8 -proc:none -cp "$SdkJar;$classes" -d $testClasses @tests
if ($LASTEXITCODE -ne 0) { throw 'Test compile failed' }
& "$JavaHome\bin\java.exe" '-Dlog4j2.disable.jmx=true' -cp "$SdkJar;$classes;$testClasses" servostar.fleet.transfer.TransferTest $jarPath
if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
& "$JavaHome\bin\java.exe" '-Dlog4j2.disable.jmx=true' -cp "$SdkJar;$testClasses" servostar.fleet.transfer.PluginLoadTest $jarPath
if ($LASTEXITCODE -ne 0) { throw 'Plugin load test failed' }
Get-FileHash -LiteralPath $jarPath -Algorithm SHA256
