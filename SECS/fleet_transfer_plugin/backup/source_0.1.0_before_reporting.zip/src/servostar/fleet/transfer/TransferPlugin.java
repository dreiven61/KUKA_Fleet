package servostar.fleet.transfer;

import org.laxture.sbp.SpringBootPlugin;
import org.laxture.sbp.spring.boot.SpringBootstrap;
import org.pf4j.PluginWrapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Runs in Interface Platform; does not start a separate web server. */
public final class TransferPlugin extends SpringBootPlugin {
    public TransferPlugin(PluginWrapper wrapper) { super(wrapper); }

    @Override protected SpringBootstrap createSpringBootstrap() {
        return new SpringBootstrap(this, Bootstrap.class)
            .addPresetProperty("spring.config.name", "servostar-transfer")
            .addPresetProperty("spring.main.banner-mode", "off");
    }

    @Configuration(proxyBeanMethods = false)
    public static class Bootstrap {
        @Bean public TransferController servoStarTransferController() {
            return new TransferController(new TransferService(new FleetHttpClient()));
        }
    }
}
