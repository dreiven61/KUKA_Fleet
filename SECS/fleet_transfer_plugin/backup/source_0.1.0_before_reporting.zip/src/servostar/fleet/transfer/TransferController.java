package servostar.fleet.transfer;

import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping({"/api/mes-transfer", "/interfaces/api/mes-transfer"})
public final class TransferController {
    private final TransferService service;
    public TransferController(TransferService service) { this.service = service; }

    @PostMapping(value="/preview", consumes="application/json", produces="application/json")
    public ResponseEntity<Map<String,Object>> preview(@RequestHeader(value="Authorization", required=false) String token,
                                                     @RequestBody Map<String,Object> request) {
        return handle(request, token, false);
    }
    @PostMapping(value="/submit", consumes="application/json", produces="application/json")
    public ResponseEntity<Map<String,Object>> submit(@RequestHeader(value="Authorization", required=false) String token,
                                                    @RequestBody Map<String,Object> request) {
        return handle(request, token, true);
    }
    private ResponseEntity<Map<String,Object>> handle(Map<String,Object> request, String token, boolean submit) {
        try { return ResponseEntity.ok(submit ? service.submit(request,token) : service.preview(request,token)); }
        catch (SecurityException ex) { return error(401,"AUTH_REJECTED", "Fleet Authorization/preflight rejected."); }
        catch (IllegalArgumentException ex) { return error(400,"INVALID_OR_DUPLICATE_REQUEST", ex.getMessage()); }
        catch (Exception ex) {
            // Do not expose transport exception bodies/headers or imply the operation failed to arrive.
            return error(502,"VERIFY_JOB_BEFORE_RETRY", "Fleet response unavailable. Query COMMANDID before retrying; do not generate a new ID to replay.");
        }
    }
    private ResponseEntity<Map<String,Object>> error(int status, String code, String message) {
        return ResponseEntity.status(status).body(TransferService.map("success",false,"code",code,"message",message,"completed",false));
    }
}
