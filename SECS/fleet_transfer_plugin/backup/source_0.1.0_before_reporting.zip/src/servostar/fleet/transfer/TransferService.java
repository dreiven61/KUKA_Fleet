package servostar.fleet.transfer;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Scalar SECS parameters -> the locally verified Fleet submitMission schema. */
public final class TransferService {
    public interface FleetClient {
        Map<String,Object> post(String path, String authorization, Map<String,Object> body) throws Exception;
    }
    private final FleetClient client;
    private final Set<String> submitted = Collections.newSetFromMap(new ConcurrentHashMap<String,Boolean>());
    public TransferService(FleetClient client) { this.client = client; }

    public Map<String,Object> preview(Map<String,Object> request, String token) throws Exception {
        Map<String,Object> mission = buildMission(request);
        authenticate(token);
        return map("success", true, "code", "0", "submitted", false, "data", mission);
    }

    public Map<String,Object> submit(Map<String,Object> request, String token) throws Exception {
        Map<String,Object> mission = buildMission(request);
        authenticate(token);
        String commandId = (String) mission.get("missionCode");
        if (!submitted.add(commandId)) {
            throw new IllegalArgumentException("COMMANDID already attempted. Query its job; do not replay it.");
        }
        // Reserve the ID before sending. Keep it reserved even if the response is lost.
        Map<String,Object> reply = client.post("submitMission", token, mission);
        if (reply == null || !(reply.get("success") instanceof Boolean) || !reply.containsKey("code")) {
            throw new IllegalStateException("Unrecognized Fleet response. Query COMMANDID before any further action.");
        }
        Map<String,Object> result = new LinkedHashMap<String,Object>(reply);
        result.put("commandId", commandId);
        result.put("completed", false);
        return result;
    }

    private void authenticate(String token) throws Exception {
        if (token == null || token.trim().isEmpty() || token.length() > 4096 || token.contains("\r") || token.contains("\n")) {
            throw new SecurityException("Authorization header is required.");
        }
        Map<String,Object> auth = client.post("robotQuery", token, map("robotId", "1"));
        if (auth == null || !Boolean.TRUE.equals(auth.get("success")) || !"0".equals(String.valueOf(auth.get("code")))) {
            throw new SecurityException("Fleet rejected Authorization or robotQuery preflight.");
        }
    }

    public static Map<String,Object> buildMission(Map<String,Object> request) {
        if (request == null) throw new IllegalArgumentException("Request body is required.");
        Set<String> allowed = new HashSet<String>(Arrays.asList("COMMANDID", "PRIORITY", "REPLACE", "CARRIERID", "SOURCEPORT", "DESTPORT"));
        if (!allowed.containsAll(request.keySet())) throw new IllegalArgumentException("Unknown request field.");
        String command = text(request, "COMMANDID");
        if (!command.matches("[A-Za-z0-9_-]{1,64}")) throw new IllegalArgumentException("COMMANDID: use 1-64 ASCII letters, numbers, _ or -.");
        String carrier = text(request, "CARRIERID");
        if (!"SIM_CARGO_001".equals(carrier)) throw new IllegalArgumentException("This test plugin supports SIM_CARGO_001 only.");
        String from = node(text(request, "SOURCEPORT"));
        String to = node(text(request, "DESTPORT"));
        if (from.equals(to)) throw new IllegalArgumentException("SOURCEPORT and DESTPORT must differ.");
        int priority = number(request, "PRIORITY");
        if (priority < 1 || priority > 99) throw new IllegalArgumentException("PRIORITY must be 1-99.");
        if (number(request, "REPLACE") != 0) throw new IllegalArgumentException("REPLACE=0 only; replacement is not implemented.");
        return map("orgId", "UNIVERSAL", "requestId", command, "missionCode", command,
            "missionType", "RACK_MOVE", "robotType", "LIFT", "robotIds", Arrays.asList("1"),
            "robotModels", Arrays.asList("KMP1500I"), "priority", priority, "containerCode", carrier,
            "containerModelCode", "SIM_TRAY_001", "lockRobotAfterFinish", false,
            "missionData", Arrays.asList(step(1, from, "UP_CONTAINER"), step(2, to, "DOWN_CONTAINER")));
    }
    private static Map<String,Object> step(int sequence, String position, String action) {
        return map("sequence", sequence, "position", position, "type", "NODE_POINT", "passStrategy", "AUTO",
            "actionType", action, "waitingMillis", 0, "actionConfirm", false, "actionInform", false);
    }
    private static String node(String port) {
        if ("PORT_89".equals(port)) return "lay01-dist1-89";
        if ("PORT_97".equals(port)) return "lay01-dist1-97";
        throw new IllegalArgumentException("Supported ports: PORT_89 and PORT_97.");
    }
    private static String text(Map<String,Object> request, String key) {
        Object value = request.get(key);
        if (!(value instanceof String) || ((String)value).trim().isEmpty()) throw new IllegalArgumentException(key + " is required as a string.");
        return (String)value;
    }
    private static int number(Map<String,Object> request, String key) {
        Object value = request.get(key);
        String s = value == null ? "" : value.toString();
        if (!s.matches("[0-9]{1,2}")) throw new IllegalArgumentException(key + " must be an integer.");
        return Integer.parseInt(s);
    }
    public static Map<String,Object> map(Object... pairs) {
        Map<String,Object> value = new LinkedHashMap<String,Object>();
        for (int i=0; i<pairs.length; i+=2) value.put((String)pairs[i], pairs[i+1]);
        return value;
    }
}
