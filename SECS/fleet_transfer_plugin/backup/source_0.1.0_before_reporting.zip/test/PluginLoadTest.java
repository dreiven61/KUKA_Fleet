package servostar.fleet.transfer;

import java.nio.file.*;
import org.laxture.sbp.SpringBootPluginManager;
import org.laxture.sbp.internal.PluginRequestMappingHandlerMapping;
import org.pf4j.PluginState;
import org.springframework.context.support.GenericApplicationContext;

/** Runs without our src/classes on the application classpath: exercises actual JAR loading. */
public final class PluginLoadTest {
    public static void main(String[] args) throws Exception {
        GenericApplicationContext host=new GenericApplicationContext();
        PluginRequestMappingHandlerMapping mapping=new PluginRequestMappingHandlerMapping();
        host.getBeanFactory().registerSingleton("requestMappingHandlerMapping",mapping);
        host.refresh();
        mapping.setApplicationContext(host); mapping.afterPropertiesSet();
        SpringBootPluginManager manager=new SpringBootPluginManager(Paths.get(args[0]).toAbsolutePath().getParent());
        manager.setApplicationContext(host);
        manager.setProfiles(new String[0]);
        manager.setAutoStartPlugin(false);
        manager.presetProperties("spring.config.name","servostar-transfer");
        manager.presetProperties("spring.main.banner-mode","off");
        try {
            String id=manager.loadPlugin(Paths.get(args[0]).toAbsolutePath());
            PluginState state=manager.startPlugin(id);
            if (state!=PluginState.STARTED) throw new AssertionError("Start failed: "+manager.getPluginStartingError(id));
            long count=mapping.getHandlerMethods().keySet().stream().filter(m->m.toString().contains("mes-transfer")).count();
            if(count!=2) throw new AssertionError("Expected preview+submit mappings, found "+count);
            System.out.println("PASS: SBP/PF4J loaded packaged JAR, started child context, registered preview+submit routes.");
            manager.stopPlugin(id);
            if(mapping.getHandlerMethods().keySet().stream().anyMatch(m->m.toString().contains("mes-transfer"))) throw new AssertionError("Routes remained after stop");
            System.out.println("PASS: plugin stop removed its routes.");
            manager.unloadPlugin(id);
        } finally { host.close(); }
    }
}
