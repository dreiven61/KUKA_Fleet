# SECS 제어·알람·복구 시험본 적용 방법

작성: 2026-10-28. Fleet 플러그인 **1.0.0**, Virtual MCS **2.0.0**.
로컬 빌드·모의 통신 검증 대상이며 실제 Fleet 업로드·운송 시험은 아직 하지 않았다.

## 이번 변경

PC → HSMS/SECS → Fleet 내부 사용자 정의 플러그인 → Fleet Standard API → 기존 KMP1500I 가상 AMR.
PC에서 별도 REST 브릿지를 실행하지 않는다. Fleet 안에서 REST 변환은 계속 사용한다. KUKA 기본 nav-secs/Order Engine을 수정한 것은 아니다.

기존 ECS 5556 경로는 S2F50을 API 접수 전에 응답하고 S6F12의 거부 값을 확인하지 않아, 요구한 접수·거부·복구 처리를 보장할 수 없었다. 이번 시험본은 같은 플러그인 안에 **별도 Passive SECS 수신부 5557**을 추가했다. 기존 ECS 규칙을 계속 편집할 필요는 없다. 기존 5555/5556 서비스는 보존하되 새 시험에서는 사용하지 않는다.

- Fleet: Passive / TCP5557 / Session3000.
- PC Virtual MCS: Active / 192.168.0.45 / TCP5557 / Session3000 / T3 120초.
- 기존 settings.json의 5556은 자동 변경하지 않는다. 새 EXE에서 Port를 직접5557로 바꾼다.
- 화물 SIM_CARGO_001, 작업 포트10개, AMR1/2/3 자동 배차는 유지한다.
- 설정 파일이 없거나 enabled=false이면 새 SECS 수신부는 열리지 않는다. 플러그인 Enable만으로 운송을 발행하지 않는다.

## 파일

- JAR: `C:\work\KUKA\SECS\fleet_transfer_plugin\build\servostar-mes-transfer-1.0.0.jar`
- PC: `C:\work\KUKA\VirtualMCS\dist-2.0.0\KukaVirtualMCS.exe` (배포는 폴더 전체)
- 적용 설정: 이 폴더의 `servostar-secs_READY_LOCAL_WITH_TOKEN.json`. 기존 토큰을 미리 넣었다. 이 설정 파일은 외부 공유하지 않는다.
- 공개 예제: `servostar-secs.example.json`. 토큰이 없고 enabled=false이다.
- 검증 기록: `검증결과.md`, `validation.json`.

## 사용자 적용 순서

현재 실행 중인 프로그램과 서버 설정은 자동 변경하지 않았다. 기존 운송을 완료·정리한 뒤 아래 순서로 적용한다. 미확인 작업이 남아 있으면 새로운 COMMANDID로 다시 보내지 않는다.

1. 기존 Virtual MCS/Visual Studio 실행과 SEComSimulator 연결을 종료한다. 자동 반복 이벤트도 정지하고 진행 중인 작업이 없는지 확인한다.
2. Fleet의 Equipment → Device에서 기존 `MES_SECS_TEST` 장치를 Disable한다. Reports07 규칙은 삭제하지 않는다. 새 경로는 이 장치를 사용하지 않는다.
3. 로컬 적용 설정을 서버 홈으로 복사한다. Windows PowerShell:

   ```powershell
   scp "C:\work\KUKA\SECS\native_host\servostar-secs_READY_LOCAL_WITH_TOKEN.json" servostar@192.168.0.45:~/servostar-secs.json
   ```

4. 서버에서 실행 UID/GID와 기존 볼륨을 먼저 확인한다.

   ```bash
   sudo docker exec kuka-interface id
   sudo docker inspect kuka-interface --format '{{range .Mounts}}{{println .Source " -> " .Destination}}{{end}}'
   ```

   아래는 현재 컨테이너 UID/GID로 설정과 새 저널 폴더 소유자를 맞추는 명령이다. 기존 config 디렉터리는 보존한다.

   ```bash
   plugin_uid=$(sudo docker exec kuka-interface id -u)
   plugin_gid=$(sudo docker exec kuka-interface id -g)
   sudo mkdir -p /opt/server/config
   sudo install -o "$plugin_uid" -g "$plugin_gid" -m 0640 ~/servostar-secs.json /opt/server/config/servostar-secs.json
   sudo install -d -o "$plugin_uid" -g "$plugin_gid" -m 0750 /opt/server/servostar-secs-state
   ```

5. `/opt/server/docker-compose.yml`을 백업한 뒤 **kuka-interface 서비스**에 아래 항목을 병합한다. 다른 서비스의5556 또는 secs 서비스5555에 넣는 것이 아니다. 기존 ports/volumes를 지우지 않는다.

   ```yaml
   ports:
      # 기존 포트 항목 유지
      - "5557:5557"
   volumes:
      # 기존 볼륨 항목 유지
      - /opt/server/config/servostar-secs.json:/opt/nav/config/servostar-secs.json:ro
      - /opt/server/servostar-secs-state:/opt/nav/servostar-secs-state
   ```

   `/opt/nav/config`가 이미 디렉터리로 마운트돼 있으면 설정을 그 호스트 디렉터리에 저장하는 방식도 가능하다. 최종 컨테이너 경로가 `/opt/nav/config/servostar-secs.json`인지 확인한다. 기존 `/opt/nav/robot/bin/Log` 볼륨은 보존한다. 그 안에 기존 운송 관찰 저널이 있다.

6. 설정 검증 후 Interface Platform만 재생성한다. API가 잠시 중단된다.

   ```bash
   cd /opt/server
   sudo docker compose config --quiet
   sudo docker compose up -d --no-deps kuka-interface
   ```

   포트 매핑 추가는 `docker restart`만으로 적용되지 않는다.

7. Fleet 웹에 다시 로그인한다. Interface Platform → Plugin Management에서 현재 SERVOSTAR-MES-TRANSFER 버전을 Disable한다. STANDARD-API는 유지한다. **1.0.0 JAR을 Import → Enable → STARTED**를 확인한다. 같은 플러그인의 다른 버전은 활성화하지 않는다.
8. 서버 로그에서 `Native SECS passive listener started on 5557, session 3000`을 확인한다. 설정 파일 전체를 출력하지 않는다.

   ```bash
   sudo docker logs --tail 80 kuka-interface
   sudo docker ps --filter name=kuka-interface --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
   ```

9. 새 `dist-2.0.0` EXE를 실행한다. 저장 설정이 남아 있으면 Port를5557로 변경한다. 연결 후 COMMUNICATING을 확인한다. 처음에는 연결만 확인하고 운송을 보내지 않는다.

## 한 단계씩 운송 시험

| 순서 | 사용자 동작 | 확인할 보고 |
|---|---|---|
| 1 | 실제 화물 위치에서 빈 작업 포트로 1회 전송 | S2F50 L2 HCACK4 →208 → 기존600/300번대 →207 Result0 |
| 2 | 새 작업을 보내고 픽업 시작 전에 작업 선택 → CANCEL | S2F42 HCACK4 →206 → 실제 취소 callback 후204 |
| 3 | 새 작업에서 픽업 시작 후 작업 선택 → ABORT | S2F42 HCACK4 →203 → 실제 강제취소 callback 후201 |
| 4 | 새 작업 운송 중 PAUSE | 107 → 실제 TASK_SUSPENDED 확인 후209/105 |
| 5 | 정지 확인 후 RESUME | 실제 MOVE_BEGIN/ACTION_BEGIN 확인 후210/103 |
| 6 | 통신만 해제했다가 재연결 | 미확인 S6F11/S5F1만 재전송, S2F49/S2F41 자동 재전송 없음 |

- CANCEL은 픽업 시작 이전, ABORT는 픽업 시작이 관찰된 이후만 허용한다. 상태에 맞지 않으면 HCACK2이다.
- ABORT는 Fleet의 FORCE 취소이며 물리적 비상정지가 아니다. 적재 화물을 자동 하차·원위치 복구하지 않는다. CarrierLoc는 실제 containerQuery/robotQuery로 확인한다.
- PAUSE/RESUME의 SECS 본문에는 COMMANDID가 없다. 이 새 SECS 경로가 소유한 작업 전체와 신규 접수 게이트에 적용한다. 수동 작업·다른 시스템의 작업·전체 차량 강제 정지까지 관리하지 않는다.
- API 접수만으로204/201/209/210을 만들지 않는다. WCS 통지가 없으면 결과 대기로 남는다. 실제 작업 상세와 callback을 확인한다.
- 202/205는 제어 실패 보고이며 원래 운송은 미완료 상태로 유지한다. 201/204는 제어 결과이며 정상 운송207로 바꾸지 않는다. RPTID2 공통 구조의 Result=0만 보고 정상 운송으로 판단하지 않는다.
- HCACK5는 기존 요청이 존재한다는 뜻이다. PC는 상태 확인 필요로 표시한다. ID를 바꾸어 즉시 재발행하지 않는다.

## 접수·거부 응답

- S2F50/S2F42: L2[B HCACK, L CPACK]. TRANSFER와 제어 요청은 Wbit가 있어야 처리한다. Session ID가 다른 요청은 실행하지 않는다.
- 4: Fleet API 실제 접수. 실제 완료는 후속 보고로 확인.
- 5: 이미 시도한 COMMANDID/진행 중인 같은 제어. 운송·제어 API 재호출 없음.
- 2: 현재 상태에서 실행할 수 없거나 API의 명시적 거부.
- 3 + CPACK: 누락/형식/값이 잘못된 파라미터.
- 1: 지원하지 않는 RCMD. 6: CANCEL/ABORT 대상 COMMANDID 없음.
- API 응답 유실은 거부로 단정하지 않는다. 서버는 UNCERTAIN을 저장하고 ACK를 보내지 않는다. PC는 T3 후 상태 확인 필요로 남는다. 운송은 자동 재발행하지 않는다.

## 시험용 알람 매핑 — SKI 공식 번호 아님

사용자가 승인한 별도 시험 매핑이다. 제공 SKI 사양서에는 Fleet 오류명→ALID 대응표가 없다.

| 실제 Fleet WCS warnCode | 시험 ALID(U4) | ALCD category | ALTX |
|---|---:|---:|---|
| PP_NoPath | 900001 | 6 | FLEET_PATH_NOT_FOUND |

WARNING: S5F1(ALCD0x86)와 S6F11 CEID702/RPTID6. WARN_CLEAR: S5F1(ALCD0x06)와 CEID701/RPTID6. PC는 S5F2/S6F12로 응답한다. 같은 활성 알람의 반복 통지는 중복 발생으로 보고하지 않는다.

실제 오류명을 확인한 후에만 alarmMappings에 추가한다. 미등록 warnCode는 서버 로그에 남기며 임의 ALID를 만들지 않는다. 유닛 없는 통지, WCS에서 올라오지 않는 하드웨어 알람, 전체 설비 AlarmSet101/AlarmCleared102는 범위가 아니다. 현재 작업 통지에서 확인되는 AMR1/2/3의 알람 경로를 구현했다.

경로 WARNING만으로 비정상207을 만들지 않는다. 실패한 실제 TASK_COMPLETED가 있을 때만 비정상 종료를 보고한다. Fleet 일반 실패에 대응하는 공식 ResultCode가 없어 **시험 확장 Result9000**을 사용한다. SKI 공식 코드가 아니며 운영 연동 전에 MES와 합의해야 한다. terminalResultMappings는 기본 비워두었다. 원인을 확인하지 않은 오류를 source/dest interlock5/6으로 임의 변환하지 않는다.

## 보고 보존·복구

새 저널은 `/opt/nav/servostar-secs-state/host-state.json`이다. 호스트 볼륨을 통해 컨테이너 재생성 후에도 남는다. 토큰은 없다. 기존 WCS 관찰 저널(`/opt/nav/robot/bin/Log/interface/servostar-transfer-journal.jsonl`)도 함께 보존한다.

- 보고는 송신 전에 디스크에 저장한다. S6F11 DATAID는 재전송에도 유지하고 HSMS SystemBytes는 새로 만든다. S5F1에는 DATAID가 없으므로 ALID/발생·해제와 원문 로그를 같이 확인한다.
- S6F12/S5F2가 정확한 단일 B0이어야 보고 완료로 기록한다. Nonzero/잘못된 응답은 BLOCKED로 저장하고 이후 보고도 순서대로 대기한다.
- ACK 유실은 5초 간격, 연결된 실제 시도 최대5회까지 보고만 재전송한다. 이후 BLOCKED. 단절 중에는 횟수를 추가하지 않는다. 같은 보고가 재도착할 수 있는 at-least-once 방식이다. MES도 DATAID 등을 기준으로 중복을 처리해야 한다.
- 재시작 시 미완료 운송을 다시 발행하지 않는다. 전송 중 요청의 결과가 불명확하면 UNCERTAIN으로 보존한다. 누락된 과거 WCS 통지를 현재 위치만 보고 만들어 채우지 않는다.
- 저널 손상이나 디스크 쓰기 실패 시 새 송신을 중단한다. 파일을 지워 초기화하지 않는다.
- 시험 보존 한도는 작업1000건/보고20000건/32MiB이다. 한도 도달 시 접수를 막는다. 장기 운영용 보존·정리 정책은 별도 설계가 필요하다. COMMANDID 기록을 삭제해 중복 방지를 우회하지 않는다.

### 상태 조회 / 거부 보고만 재시도

POST `http://192.168.0.45:10870/interfaces/api/mes-secs/status`

Header Authorization에 기존 Fleet 토큰을 사용한다. communicating, healthy, tsc, jobs(phase/control/controlState), 미확인 reports(dataId/state/attempts/error)가 나온다. 운송을 발행하지 않는다.

Host 거부 원인을 수정하고 보고만 다시 보내려면 POST `http://192.168.0.45:10870/interfaces/api/mes-secs/retry-report`:

```json
{"dataId": 1}
```

BLOCKED인 실제 dataId만 지정한다. 운송·제어 명령을 재실행하지 않는다. UNCERTAIN 작업을 강제로 성공 처리하거나 PAUSING 상태를 임의 해제하는 API는 없다. 서버 저널·Fleet 실제 상태를 먼저 대조한다.

## 검증과 한계

검증 기록은 `검증결과.md`를 따른다. 로컬 모의 Fleet API/저장된 WCS 통지/루프백 HSMS로 수행했다. 서버1.0.0 활성화, 실제 CANCEL/ABORT callback 순서, PAUSE/RESUME, 알람 발생·해제와 통신 복구는 적용 후 사용자가 확인해야 한다. 기존 지도·로봇·운송은 조작하지 않았다.

SECS/GEM 전체 구현 또는 SKI 전체 사양 완료가 아니다. 범위 외 S9, 전체 DV/EC, 알람 일람 조회, spool 전체 규격, 다중 화물, HA 서버, 저널 자동 회전 등은 포함하지 않는다.

기준: 제공 SKI MessageSpec p13–18(S2F41/42,49/50), p21–24(S5/S6), BasicSpec p20(201–211), p23(701/702), p34(ResultCode). Fleet API 이름/취소 모드는 설치 STANDARD-API2.15.5와 WCS stub에서 확인했다. SECS transport는 설치본 secs2.11.0이며 공급사 서버 코드는 패치하지 않았다.
