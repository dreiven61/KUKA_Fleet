# Third-party libraries

This application references Secs4Net 3.1.0 (MIT), by mkjeff and contributors.
Source and license: https://github.com/mkjeff/secs4net
License text: https://github.com/mkjeff/secs4net/blob/base/LICENSE

NuGet restore resolves the library's dependencies. Package license metadata and source links are retained in App/obj/project.assets.json after restore. This application does not redistribute the AIM SEComEnabler binaries from the existing VirtualMCS project.

## Secs4Net — MIT License

Copyright (c) Hsin-chang He

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Other NuGet runtime dependencies — MIT

CommunityToolkit.HighPerformance: Copyright (c) .NET Foundation and Contributors.
Microsoft.Extensions.*: Copyright (c) .NET Foundation and Contributors.
The MIT permission and disclaimer above apply to these components under their respective copyright notices.
