# KUKA Virtual MCS

기존 SKI VirtualMCS의 연결 버튼 / From·To 운송 생성 / 작업 목록 구성을 참고해 만든 별도 Windows WPF 프로그램이다. 기존 소스와 AIM DLL은 수정하거나 복사하지 않았다. 새 프로그램은 Secs4Net 3.1.0으로 HSMS/SECS를 직접 송수신한다.

## 실행

`실행.cmd` 또는 `dist/KukaVirtualMCS.exe`를 실행한다. Windows x64와 .NET 10 Desktop Runtime이 필요하다. 이 PC에는 해당 런타임이 설치되어 있다. 다른 PC로 옮길 때는 EXE만 복사하지 말고 `dist` 폴더 전체를 복사한다.

1. SEComSimulator의 Open Connection을 닫는다. 기존 연결이 남은 상태에서 같은 Fleet 포트에 경쟁 접속하지 않는다.
2. 기본값 `192.168.0.45 / 5556 / Session 3000 / PC Active / T3 120초`를 확인하고 **연결**을 누른다. Passive 선택 시 IP는 PC의 로컬 바인딩 주소이며 Fleet도 대응하는 Active 설정이어야 한다. 현재 시험은 기본 Active를 사용한다.
3. HSMS Selected 후 S1F13을 자동 전송한다. 우측 상태가 **COMMUNICATING**이면 운송 버튼이 활성화된다. 필요할 때 S1F13/S1F17 버튼을 별도로 사용할 수 있다.
4. Fleet에서 `SIM_CARGO_001`의 실제 위치를 확인하고 **89 → 97 전송**, **97 → 89 전송** 또는 From/To 선택 후 **선택 경로 전송**을 한 번 누른다.
5. COMMANDID는 매 작업마다 시간+GUID로 자동 생성한다. 직접 편집할 필요가 없다. REPLACE=0 고정, PRIORITY 1~99이다.

## 작업과 보고

- S2F49 구조는 현재 Fleet ECS에서 사용하는 COMMANDINFO / TRANSFERINFO의 이름-값 쌍 형식이다. 현재 서버 플러그인 범위인 AMR1 / SIM_CARGO_001 / PORT_89↔PORT_97만 지원한다.
- S2F50 단일 B=0과 L[2] HCACK 형식을 모두 읽는다. 현재 Fleet은 운송 API 결과가 나오기 전에 B=0을 응답하므로 **응답 수신을 운송 접수·완료로 표시하지 않는다**. 서버가 이후 거부하면 이 프로그램에는 완료가 없을 수 있다.
- S6F11 RPTID2에서 COMMANDID·화물·출발·도착이 일치하는 보고만 작업에 반영한다. CEID208 시작, 211 진행, 207 완료/비정상 종료를 구분한다. 정상 207은 Result=0과 최종 CarrierLoc=도착 포트가 모두 맞아야 완료로 표시한다.
- 수신 S6F11에는 S6F12, S5F1에는 S5F2를 자동 응답한다. 형식이 잘못된 S6F11은 ACKC6=1로 응답한다. ACK는 메시지 수신 처리 결과이며 실제 운송 완료 판정과 다르다.
- **완료 보고 후 From/To 교환**이 체크돼 있으면 정상 207 수신 후 입력 방향만 바꾼다. 반대편 운송을 자동으로 보내지 않는다. 다음 버튼 클릭에서 새 ID를 만든다.
- 미확인 화물 작업이 있으면 추가 전송을 차단한다. 중복 클릭·T3 타임아웃·연결 복구 때 S2F49를 자동 재전송하지 않는다. 응답 유실/연결 단절/프로그램 재시작 후 미완료 건은 상태 확인 필요로 남긴다.
- 완료 보고가 안 오거나 서버에서 거부한 경우, Fleet에서 기존 작업 상태와 실제 화물 위치를 먼저 확인한다. 그 뒤 작업 목록에서 해당 건을 선택해 **현장 확인 후 대기 해제**를 누르면 로컬 추가 전송 차단만 해제한다. 이것은 Fleet 취소 명령도, 운송 완료 처리도 아니다.
- S5F1 알람은 로그에 별도 표시한다. 서버가 보고하지 않는 진행·완료·abnormal 정보를 생성하지 않는다. CANCEL/ABORT/RESUME, 자동 반복 운전, Fleet 설정 수정은 구현하지 않았다.

## 저장 위치

`%LOCALAPPDATA%\ServoStar\KukaVirtualMCS\`

- `settings.json`: 연결 설정. Fleet REST 토큰을 사용하거나 저장하지 않는다.
- `jobs.jsonl`: 전송 시도 전 의도를 디스크에 저장하고 이후 상태를 누적한다. 사용한 ID 및 미확인 작업을 재시작 후에도 유지한다. 파일 손상 시 임의 삭제/초기화하지 않고 시작을 중단한다.
- `logs\secs_yyyyMMdd.log`: SystemBytes 포함 TX/RX SML, 이벤트, 알람. UI는 최근 로그만 표시하며 **화면 로그 지우기**는 파일을 삭제하지 않는다.

## 소스 / 빌드 / 검증

`KukaVirtualMCS.sln`을 열거나 PowerShell에서 `./build.ps1`을 실행한다. .NET 10 SDK와 NuGet 복원이 필요하다. `Core`는 메시지·상태·통신, `App`은 WPF 화면, `Tests`는 실제 Fleet에 접속하지 않는 로컬 모의 HSMS 시험이다.

2026-10-27: 로컬 36개 검사에서 S2F49 본문/FromTo, HSMS Select·자동 S1F13, S1F17, S2F50 두 형식, 208/211/207·S6F12, S5F1/S5F2, 타임아웃과 중복 차단, 재시작 상태 복구를 검증했다. 현재 Fleet과의 실제 송수신/운송은 사용자 연결 후 확인해야 한다.

라이브러리 공식 자료: https://github.com/mkjeff/secs4net
